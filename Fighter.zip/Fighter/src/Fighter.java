public class Fighter {
    private String name;
    private int attack;
    private int defense;
    private Enum element;

    public Fighter (String n, int a, int d, Enum e){
        name = n;
        attack = a;
        defense = d;
        element = e;
    }
    public String getName (){
        return name;
    }
    public int getAttack (){
        return attack;
    }
    public int getDefense (){
        return defense;
    }
    public Enum getElement (){
        return element;
    }

}
