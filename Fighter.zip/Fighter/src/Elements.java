public enum Elements {
    FIRE, WATER, GRASS
}
